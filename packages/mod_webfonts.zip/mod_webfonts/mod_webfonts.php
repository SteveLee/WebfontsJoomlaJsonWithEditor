<?php
/**
 * Copyright 2010 Monotype Imaging Inc.  
 * This program is distributed under the terms of the GNU General Public License
 */
 
//don't allow other scripts to grab and execute our file
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

$component_location = JPATH_SITE . DS . 'administrator'. DS . 'components' . DS . 'com_webfonts';
require_once( $component_location.DS.'libraries'.DS.'includes.php' );

$params = &JComponentHelper::getParams('com_webfonts');
$db =& JFactory::getDBO();
$document =& JFactory::getDocument();

$userid = $params->get( 'wfs_user_id' );
$query = "SELECT project_key,project_page_option,project_options,project_pages,project_day,wysiwyg_enabled,editor_select FROM #__wfs_configure WHERE `is_active` = '1' and `user_id` = '$userid' ORDER BY updated_date DESC";
$db->setQuery( $query);
$rows = $db->loadObjectList();
foreach($rows as $data)
	{
	$dayValue = $data->project_day;
	if(checkday($dayValue)){
			$project[]=$data->project_key;
			$project[]=$data->project_options;
			$project[]=$data->wysiwyg_enabled;
			$project[]=$data->editor_select;
			break;
		}	
}

$key =$project[0];
if($project[1] == 0) 
	{
		$js = FFJSAPIURI.$key.".js";
		$document->addScript($js);
	}else{
		$css = FFCSSURL.$key.".css";
		$document->addStyleSheet($css);
	}

?>
