CKFinder is a powerful and easy to use Ajax file manager for web browsers, 
to find out more about CKFinder, please visit the official web site: 
http://ckfinder.com/

The installation instruction is available in the CKEditor administration
area, to access it please login as administrator and go to:
Components -> CKEditor -> File browser settings